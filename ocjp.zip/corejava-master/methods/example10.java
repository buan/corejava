class example10
{	
	int a=10;
	int m1()
	{
		return a;
	}
	
	public static void main(String args[])
	{
		example10 e=new example10();
		System.out.println(e.m1());
	}
}