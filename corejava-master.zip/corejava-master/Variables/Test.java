class Test 
{
	public static void main(String[] args) //main method
	{
		//local variables
		int a=20;
		int b=30;
		System.out.println(a+b);
	}
}
