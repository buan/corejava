class test3
{

public static void main(String args[])
	{
 int a;
 boolean b;
System.out.println(a);
System.out.println(b);
	}

}