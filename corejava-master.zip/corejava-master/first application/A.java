/*step 1:select editorpreferably edit plus
step2:write the application

import java.lang.* or java.lang.System/String(second one is better)

classes with access specifier as public should be saved with that name.there should be one class with public.
if nothing is public we can give any name
*/
import java.lang.System;
import java.lang.String;
class test
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}

public class A
{
}

class B
{
}
